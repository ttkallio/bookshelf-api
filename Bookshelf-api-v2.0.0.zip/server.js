// server.js
require("dotenv").config(); // Load .env file for local development (harmless in production if .env missing)
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const { v4: uuidv4 } = require("uuid");

const app = express();
// Read API port from environment variable or default to 3001
const port = process.env.API_PORT || 3001;

// --- Database Connection Pool ---
// Configure using environment variables for production compatibility
const pool = mysql.createPool({
  host: process.env.DB_HOST, // Read from environment variable
  port: process.env.DB_PORT || 3306, // Read from environment variable or default
  user: process.env.DB_USER, // Read from environment variable
  password: process.env.DB_PASSWORD, // Read from environment variable
  database: process.env.DB_DATABASE, // Read from environment variable
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // timezone: "+00:00",
});

// --- Middleware ---
// TODO: Configure CORS more strictly for production
app.use(cors());
/* Example Production CORS Configuration:
const corsOptions = {
  origin: process.env.FRONTEND_URL || "YOUR_FRONTEND_DEPLOYMENT_URL", // e.g., https://d123.cloudfront.net
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
*/
app.use(express.json()); // Enable parsing JSON request bodies

// --- API Routes ---

// GET /api/books - Retrieve all books
app.get("/api/books", async (req, res) => {
  console.log("Received request: GET /api/books");
  try {
    const [rows] = await pool.query("SELECT * FROM books ORDER BY dateAdded DESC");
    console.log(`Found ${rows.length} books.`);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching books:", error);
    res.status(500).json({ error: "Error fetching books from database" });
  }
});

// GET /api/books/:id - Retrieve a single book by ID
app.get("/api/books/:id", async (req, res) => {
  const { id } = req.params;
  console.log(`Received request: GET /api/books/${id}`);
  try {
    const sql = "SELECT * FROM books WHERE id = ?";
    const params = [id];
    const [rows] = await pool.query(sql, params);

    if (rows.length === 0) {
      console.log(`Book not found for ID: ${id}`);
      res.status(404).json({ error: "Book not found" });
    } else {
      console.log(`Book found for ID: ${id}`);
      res.json(rows[0]);
    }
  } catch (error) {
    console.error(`Error fetching book with ID ${id}:`, error);
    res.status(500).json({ error: "Error fetching book from database" });
  }
});


// POST /api/books - Add a new book
app.post("/api/books", async (req, res) => {
  console.log("Received request: POST /api/books");
  const { title, author, listType, genre, yearPublished, rating, notes } = req.body;

  // Validation
  if (!title || !author || !listType) {
    return res.status(400).json({ error: "Missing required fields: title, author, and listType are required." });
  }
  if (!["owned", "want"].includes(listType)) {
      return res.status(400).json({ error: "Invalid listType. Must be 'owned' or 'want'." });
  }
  if (rating !== null && rating !== undefined && (typeof rating !== "number" || rating < 1 || rating > 5)) {
      return res.status(400).json({ error: "Invalid rating. Must be a number between 1 and 5." });
  }

  const newBookId = uuidv4();
  const dateAdded = new Date();
  const insertSql = `
    INSERT INTO books
      (id, title, author, genre, yearPublished, rating, notes, listType, dateAdded)
    VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  const params = [
    newBookId, title, author, genre || null, yearPublished || null,
    rating || null, notes || null, listType, dateAdded
  ];

  try {
    const [result] = await pool.query(insertSql, params);
    if (result.affectedRows === 1) {
      const newBook = {
        id: newBookId, title, author, genre: genre || null,
        yearPublished: yearPublished || null, rating: rating || null,
        notes: notes || null, listType, dateAdded
      };
      console.log("Book added successfully:", newBookId);
      res.status(201).json(newBook);
    } else {
      throw new Error("Insert query affected 0 rows.");
    }
  } catch (error) {
    console.error("Error adding book:", error);
    res.status(500).json({ error: "Error adding book to database" });
  }
});

// PUT /api/books/:id - Update an existing book
app.put("/api/books/:id", async (req, res) => {
  const { id } = req.params;
  console.log(`Received request: PUT /api/books/${id}`);
  const { title, author, listType, genre, yearPublished, rating, notes } = req.body;

  // Validation
  if (!title || !author || !listType) {
    return res.status(400).json({ error: "Missing required fields: title, author, and listType are required." });
  }
  if (!["owned", "want"].includes(listType)) {
      return res.status(400).json({ error: "Invalid listType. Must be 'owned' or 'want'." });
  }
  if (rating !== null && rating !== undefined && (typeof rating !== "number" || rating < 1 || rating > 5)) {
      return res.status(400).json({ error: "Invalid rating. Must be a number between 1 and 5." });
  }

  const updateSql = `
    UPDATE books SET
      title = ?, author = ?, genre = ?, yearPublished = ?,
      rating = ?, notes = ?, listType = ?
    WHERE id = ?
  `;
  const params = [
    title, author, genre || null, yearPublished || null,
    rating || null, notes || null, listType, id
  ];

  try {
    const [result] = await pool.query(updateSql, params);
    if (result.affectedRows === 0) {
      console.log(`Book not found for update with ID: ${id}`);
      return res.status(404).json({ error: "Book not found" });
    }

    const [updatedBookRows] = await pool.query("SELECT * FROM books WHERE id = ?", [id]);
    if (updatedBookRows.length === 0) {
        console.error(`Failed to fetch updated book after update for ID: ${id}`);
        return res.status(500).json({ error: "Failed to retrieve updated book data." });
    }
    console.log("Book updated successfully:", id);
    res.json(updatedBookRows[0]);

  } catch (error) {
    console.error(`Error updating book with ID ${id}:`, error);
    res.status(500).json({ error: "Error updating book in database" });
  }
});

// DELETE /api/books/:id - Delete a book
app.delete("/api/books/:id", async (req, res) => {
  const { id } = req.params;
  console.log(`Received request: DELETE /api/books/${id}`);
  const sql = "DELETE FROM books WHERE id = ?";
  const params = [id];

  try {
    const [result] = await pool.query(sql, params);
    if (result.affectedRows === 0) {
      console.log(`Book not found for delete with ID: ${id}`);
      return res.status(404).json({ error: "Book not found" });
    }
    console.log("Book deleted successfully:", id);
    res.status(204).send(); // Standard practice for successful DELETE

  } catch (error) {
    console.error(`Error deleting book with ID ${id}:`, error);
    res.status(500).json({ error: "Error deleting book from database" });
  }
});


// --- Basic Root Route ---
app.get("/", (req, res) => {
  // Basic health check / root route response
  console.log("--- GET / request received ---");
  res.send("Bookshelf API is running!");
});


// --- Start Server (Restored Original Logic) ---
// Verify essential environment variables are set before trying to connect/start
if (!process.env.DB_HOST || !process.env.DB_USER || !process.env.DB_PASSWORD || !process.env.DB_DATABASE) {
    console.error("FATAL ERROR: Database configuration environment variables (DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE) are not set.");
    process.exit(1); // Exit if essential config is missing
}

// Check DB connection before starting listener
pool.query("SELECT 1")
  .then(() => {
    console.log("MySQL Database connected successfully.");
    // Start listening only after successful DB connection
    app.listen(port, () => {
      console.log(`Bookshelf API server listening on port ${port}`);
    });
  })
  .catch(error => {
     // Catch errors during the initial DB connection test
     console.error("FATAL ERROR: Error connecting to MySQL Database on startup:", error);
     process.exit(1); // Exit if DB connection fails on startup
  });
